
const { buildReply } = require("../services/replyBuilder")

async function handleMessage(uid,text){
  if(text.includes("充值")) return buildReply("deposit_not_arrived")
  if(text.includes("提款")) return buildReply("withdraw_pending")
  return "請描述你的問題"
}

module.exports = { handleMessage }
