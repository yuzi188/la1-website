
const { SOP } = require("./sopLibrary")
const { getRandom } = require("./scriptLibrary")

function buildReply(intent){
  const data = SOP[intent]
  if(!data) return null
  let r = `【${data.title}】\n`
  r += data.steps.map((s,i)=>`${i+1}. ${s}`).join("\n")+"\n"
  r += "解決方式:\n"+data.solutions.join("\n")+"\n"
  r += "💡 "+getRandom(intent.includes("deposit")?"deposit":"common")
  return r
}
module.exports = { buildReply }
