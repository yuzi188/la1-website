
const SOP = {
deposit_not_arrived:{
title:"充值未到帳",
steps:["確認TRC20","確認時間","確認TxID"],
solutions:["區塊未確認→等","錯鏈→人工","地址錯→無法找回"]
},
withdraw_pending:{
title:"提款審核中",
steps:["確認時間","確認金額","查看狀態"],
solutions:["正常審核→等","高峰延遲","風控人工"]
},
bet_failed:{
title:"下注失敗",
steps:["確認餘額","確認賽事","確認金額"],
solutions:["餘額不足","賽事關閉","限額"]
},
login_issue:{
title:"登入問題",
steps:["重新登入","檢查帳密","重設密碼"],
solutions:["密碼錯","驗證問題","系統延遲"]
}
}
module.exports = { SOP }
