
function detectIntent(text = ""){
  const t = String(text)

  if(t.includes("充值")) return "deposit"
  if(t.includes("提款")) return "withdraw"
  if(t.includes("登入")) return "login"
  if(t.includes("下注")) return "bet"

  return "unknown"
}

module.exports = { detectIntent }
