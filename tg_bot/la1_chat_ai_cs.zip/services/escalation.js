
const failCount = {}

function shouldEscalate(userId, success){
  if(!failCount[userId]) failCount[userId] = 0
  if(!success) failCount[userId]++
  else failCount[userId] = 0
  return failCount[userId] >= 3
}

module.exports = { shouldEscalate }
