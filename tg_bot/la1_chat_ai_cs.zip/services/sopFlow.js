
const { clearState } = require("./stateManager")

function runFlow(userId, text, state){
  const { intent, step } = state

  if(intent === "deposit"){
    if(step === 1){
      state.step = 2
      return "我先幫你看一下～\n👉 你是用哪條鏈充值的？"
    }
    if(step === 2){
      state.step = 3
      return "OK，那大概什麼時間轉的？"
    }
    if(step === 3){
      clearState(userId)
      return "好，正常1-3分鐘會到帳，我幫你看 👍"
    }
  }

  if(intent === "withdraw"){
    if(step === 1){
      state.step = 2
      return "你什麼時間申請提款的？"
    }
    if(step === 2){
      clearState(userId)
      return "通常審核5-30分鐘，我幫你看 👍"
    }
  }

  return null
}

module.exports = { runFlow }
