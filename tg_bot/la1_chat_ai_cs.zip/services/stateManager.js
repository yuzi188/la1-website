
const userState = {}

function getState(userId){
  return userState[userId]
}

function setState(userId, state){
  userState[userId] = state
}

function clearState(userId){
  delete userState[userId]
}

module.exports = { getState, setState, clearState }
