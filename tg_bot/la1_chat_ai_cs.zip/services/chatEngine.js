
const { detectIntent } = require("./intentDetector")
const { getState, setState } = require("./stateManager")
const { runFlow } = require("./sopFlow")
const { shouldEscalate } = require("./escalation")

async function chat(userId, text){
  const state = getState(userId)

  if(state){
    const flowReply = runFlow(userId, text, state)
    if(flowReply) return flowReply
  }

  const intent = detectIntent(text)

  if(intent !== "unknown"){
    const newState = { intent, step: 1 }
    setState(userId, newState)
    return runFlow(userId, text, newState)
  }

  if(!text || text.length < 10){
    return "我在～可以跟我說一下你遇到什麼問題嗎？我幫你看 👍"
  }

  if(shouldEscalate(userId, false)){
    return "這個我幫你轉專員會比較快處理 🙏"
  }

  return "我大概理解你的意思，可以再說詳細一點嗎？我幫你處理"
}

module.exports = { chat }
