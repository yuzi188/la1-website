
const { chat } = require("../services/chatEngine")

async function handleMessage(userId, text){
  return await chat(userId, text)
}

module.exports = { handleMessage }
